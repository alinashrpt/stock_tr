# stock-simulator
A stock-trading-simulator

### Click here --- https://pvn-leo.github.io/stock-simulator


This stock-trading simulator was built using html, bootstrap css, and javascript. 


## Rules  

```
1. Initial $10000 credit.   
2. Buy and sell only one stock at a time.  
```

## Limitations  
```
1. Data types of cashflow and portfolio value are floating points.  
2. It is not responsive on smaller sized windows.
```

<br/>
This work is strictly meant for '<i>fun</i>' purposes and in no way does it mean any kind of conflicts with the companies listed in it.

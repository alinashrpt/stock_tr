
(function ($) {
    "use strict";
})(jQuery);
